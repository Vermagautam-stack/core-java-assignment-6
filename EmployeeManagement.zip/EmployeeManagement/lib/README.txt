Place the MySQL JDBC driver here, named: mysql-connector-java.jar
Download: https://dev.mysql.com/downloads/connector/j/  (choose "Platform Independent", extract the .jar)
