# EmployeeManagement

Java Swing + JDBC desktop application (CSIT751 – Module VI practical assignment).
Add employees to a MySQL database and view all records in a table.

## Structure
```
EmployeeManagement/
├── src/com/example/
│   ├── EmployeeForm.java   (Swing frontend)
│   └── EmployeeDAO.java    (JDBC logic)
├── lib/
│   └── mysql-connector-java.jar   (add the driver here)
└── database.sql
```

## Setup
1. Install MySQL and run `database.sql` (the app also creates the DB/table automatically if missing).
2. Download the MySQL Connector/J jar and put it in `lib/` as `mysql-connector-java.jar`.
3. In `EmployeeDAO.java`, set `USER` and `PASSWORD` to your MySQL credentials.

## Run
```
javac -cp "lib/mysql-connector-java.jar" -d bin src/com/example/*.java
java  -cp "bin;lib/mysql-connector-java.jar" com.example.EmployeeForm     (Windows)
java  -cp "bin:lib/mysql-connector-java.jar" com.example.EmployeeForm     (Linux/Mac)
```
In Eclipse/IntelliJ: add the jar to the build path and run `EmployeeForm`.
