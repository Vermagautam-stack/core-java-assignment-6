package com.example;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.sql.SQLException;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

/**
 * Swing frontend for the Employee Management application.
 */
public class EmployeeForm extends JFrame {

    private static final long serialVersionUID = 1L;

    private final JTextField idField = new JTextField(15);
    private final JTextField nameField = new JTextField(15);
    private final JTextField deptField = new JTextField(15);
    private final JTextField salaryField = new JTextField(15);

    private final DefaultTableModel tableModel =
            new DefaultTableModel(new String[]{"Employee ID", "Name", "Department", "Salary"}, 0) {
                private static final long serialVersionUID = 1L;
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

    private final EmployeeDAO dao;

    public EmployeeForm(EmployeeDAO dao) {
        super("Employee Management");
        this.dao = dao;
        buildUI();
    }

    private void buildUI() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(600, 450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // ---- Form panel ----
        JPanel form = new JPanel(new GridLayout(4, 2, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Add New Employee"));
        form.add(new JLabel("Employee ID:"));
        form.add(idField);
        form.add(new JLabel("Name:"));
        form.add(nameField);
        form.add(new JLabel("Department:"));
        form.add(deptField);
        form.add(new JLabel("Salary:"));
        form.add(salaryField);

        // ---- Buttons ----
        JButton submitBtn = new JButton("Submit");
        JButton viewBtn = new JButton("View All Employees");
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        buttons.add(submitBtn);
        buttons.add(viewBtn);

        JPanel top = new JPanel(new BorderLayout());
        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));

        // ---- Table ----
        JTable table = new JTable(tableModel);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(0, 10, 10, 10),
                BorderFactory.createTitledBorder("Employee Records")));

        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        submitBtn.addActionListener(e -> submitEmployee());
        viewBtn.addActionListener(e -> viewAllEmployees());
    }

    private void submitEmployee() {
        String idText = idField.getText().trim();
        String name = nameField.getText().trim();
        String dept = deptField.getText().trim();
        String salaryText = salaryField.getText().trim();

        if (idText.isEmpty() || name.isEmpty() || dept.isEmpty() || salaryText.isEmpty()) {
            showError("All fields are required.");
            return;
        }

        int id;
        double salary;
        try {
            id = Integer.parseInt(idText);
        } catch (NumberFormatException ex) {
            showError("Employee ID must be an integer.");
            return;
        }
        try {
            salary = Double.parseDouble(salaryText);
        } catch (NumberFormatException ex) {
            showError("Salary must be a valid number.");
            return;
        }

        try {
            dao.addEmployee(id, name, dept, salary);
            JOptionPane.showMessageDialog(this, "Employee added successfully!");
            clearFields();
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1062) { // duplicate primary key in MySQL
                showError("An employee with ID " + id + " already exists.");
            } else {
                showError("Database error: " + ex.getMessage());
            }
        }
    }

    private void viewAllEmployees() {
        try {
            List<Object[]> rows = dao.getAllEmployees();
            tableModel.setRowCount(0);
            for (Object[] row : rows) {
                tableModel.addRow(row);
            }
            if (rows.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No employee records found.");
            }
        } catch (SQLException ex) {
            showError("Database error: " + ex.getMessage());
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        deptField.setText("");
        salaryField.setText("");
        idField.requestFocus();
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                EmployeeDAO dao = new EmployeeDAO();
                new EmployeeForm(dao).setVisible(true);
            } catch (RuntimeException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(),
                        "Startup Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
