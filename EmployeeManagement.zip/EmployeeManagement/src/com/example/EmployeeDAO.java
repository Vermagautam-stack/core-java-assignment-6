package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC logic: connects to MySQL (company_db) and handles employee records.
 */
public class EmployeeDAO {

    // ---- Change these to match your MySQL setup ----
    private static final String SERVER_URL = "jdbc:mysql://localhost:3306/";
    private static final String DB_NAME = "company_db";
    private static final String URL = SERVER_URL + DB_NAME;
    private static final String USER = "root";
    private static final String PASSWORD = "your_password";

    public EmployeeDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL JDBC driver not found. Add mysql-connector-java.jar to lib/ and the classpath.", e);
        }
        initDatabase();
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    /** Creates company_db and the employees table if they do not exist. */
    private void initDatabase() {
        try (Connection con = DriverManager.getConnection(SERVER_URL, USER, PASSWORD);
             Statement st = con.createStatement()) {
            st.executeUpdate("CREATE DATABASE IF NOT EXISTS " + DB_NAME);
        } catch (SQLException e) {
            throw new RuntimeException("Could not connect to MySQL: " + e.getMessage(), e);
        }
        String ddl = "CREATE TABLE IF NOT EXISTS employees ("
                + "emp_id INT PRIMARY KEY, "
                + "name VARCHAR(100), "
                + "department VARCHAR(50), "
                + "salary DECIMAL(10,2))";
        try (Connection con = getConnection(); Statement st = con.createStatement()) {
            st.executeUpdate(ddl);
        } catch (SQLException e) {
            throw new RuntimeException("Could not create table: " + e.getMessage(), e);
        }
    }

    /** Inserts a new employee. */
    public void addEmployee(int id, String name, String department, double salary) throws SQLException {
        String sql = "INSERT INTO employees (emp_id, name, department, salary) VALUES (?, ?, ?, ?)";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(3, department);
            ps.setDouble(4, salary);
            ps.executeUpdate();
        }
    }

    /** Returns all employees as rows: {emp_id, name, department, salary}. */
    public List<Object[]> getAllEmployees() throws SQLException {
        List<Object[]> rows = new ArrayList<>();
        String sql = "SELECT emp_id, name, department, salary FROM employees ORDER BY emp_id";
        try (Connection con = getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                rows.add(new Object[]{
                        rs.getInt("emp_id"),
                        rs.getString("name"),
                        rs.getString("department"),
                        rs.getBigDecimal("salary")
                });
            }
        }
        return rows;
    }
}
